# exporters/base_exporter.py
import os
import time
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import config

class BasePDFExporter:
    def __init__(self):
        self._init_fonts()
        self._init_styles()

    def _init_fonts(self):
        try:
            pdfmetrics.registerFont(TTFont("TimesNewRoman", config.FONT_PATH_REGULAR))
            pdfmetrics.registerFont(TTFont("TimesNewRoman-Bold", config.FONT_PATH_BOLD))
            self.FONT_REGULAR, self.FONT_BOLD = "TimesNewRoman", "TimesNewRoman-Bold"
        except:
            self.FONT_REGULAR, self.FONT_BOLD = "Helvetica", "Helvetica-Bold"

    def _init_styles(self):
        self.styles = getSampleStyleSheet()
        self.styles.add(ParagraphStyle(name="font_title", fontName=self.FONT_BOLD, fontSize=22, alignment=1, leading=33))
        self.styles.add(ParagraphStyle(name="font_section", fontName=self.FONT_BOLD, fontSize=20, leading=30))
        self.styles.add(ParagraphStyle(name="font_text", fontName=self.FONT_REGULAR, fontSize=16, leading=24))

        self.table_style_common = TableStyle([
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ("FONTNAME", (0, 0), (-1, -1), self.FONT_REGULAR),
            ("FONTSIZE", (0, 0), (-1, -1), 14),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ])
        
        # 定义三种表格样式供子类调用
        self.style_blank = TableStyle([('VALIGN', (0, 0), (-1, -1), 'MIDDLE'), ("FONTNAME", (0, 0), (-1, -1), self.FONT_REGULAR)])
        self.style_threeline = TableStyle([("LINEABOVE", (0, 0), (-1, 0), 2, colors.black), ("LINEBELOW", (0, 0), (-1, 0), 1, colors.black), ("LINEBELOW", (0, -1), (-1, -1), 2, colors.black), ("VALIGN", (0, 0), (-1, -1), 'MIDDLE')])

    def generate_row_content(self, df_record):
        """
        【抽象方法】这是子类必须实现的核心差异方法。
        输入：单张图片的 DataFrame
        输出：(data_rows, row_heights)
        """
        raise NotImplementedError("Subclasses must implement generate_row_content")

    def export(self, report_data, save_path):
        print(f"[{time.strftime('%H:%M:%S')}] PDF Generation started ({self.__class__.__name__})...")
        doc = SimpleDocTemplate(save_path, pagesize=letter)
        elements = []

        # --- 1. 通用表头与摘要 (所有样式都一样) ---
        self._add_summary_pages(elements, report_data)

        # --- 2. 详细内容 (差异化部分) ---
        elements.append(Paragraph("Detailed Information:", self.styles["font_section"]))
        elements.append(Spacer(1, 10))

        records_df_list = report_data['records']
        all_data_rows = []
        all_row_heights = []

        from tqdm import tqdm
        for df_record in tqdm(records_df_list, desc="Building Table Rows"):
            if df_record.empty: continue
            
            # 调用子类的方法获取行数据
            rows, heights = self.generate_row_content(df_record)
            all_data_rows.extend(rows)
            all_row_heights.extend(heights)

        # --- 3. 构建并保存表格 ---
        if all_data_rows:
            # 简单的长度保护
            min_len = min(len(all_data_rows), len(all_row_heights))
            all_data_rows = all_data_rows[:min_len]
            all_row_heights = all_row_heights[:min_len]

            # 创建大表
            from reportlab.lib.units import inch
            t = Table(all_data_rows, hAlign='CENTER', colWidths=[2*inch, 4*inch], rowHeights=all_row_heights)
            
            # 应用斑马纹或合并文件名的样式
            final_style = TableStyle(self.table_style_common.getCommands())
            for i, row in enumerate(all_data_rows):
                if row[0] == 'FileName':
                    final_style.add('SPAN', (0, i), (-1, i))
                    final_style.add('BACKGROUND', (0, i), (-1, i), colors.lightgrey)
            t.setStyle(final_style)
            elements.append(t)
        else:
            elements.append(Paragraph("No defects detected.", self.styles["font_text"]))

        try:
            doc.build(elements)
            print(f"Success! Saved to {save_path}")
        except Exception as e:
            print(f"Error: {e}")

    def _add_summary_pages(self, elements, report_data):
        """生成摘要页的通用逻辑"""
        input_info = report_data['input']
        output_info = report_data['output']
        
        elements.append(Paragraph("<b>AI-Detection Result Report</b>", self.styles["font_title"]))
        elements.append(Spacer(1, 30))
        
        # 这里省略了 summary 表格的具体构建代码（和之前一样），只为展示结构
        # ... 构建 Input Info 表格 ...
        # ... 构建 Summary 表格 ...
        # ... 构建 Statistics 表格 ...
        elements.append(PageBreak())