# exporters/pdf_styles.py
import os
from pathlib import Path
from reportlab.platypus import Image as RLImage
from reportlab.platypus import Table, Spacer, Paragraph
from reportlab.lib.units import inch
from .base_exporter import BasePDFExporter

class PDFExporterBasic(BasePDFExporter):
    """
    样式 0: 基础报告 (只包含图片、类别、等级、建议)
    """
    def generate_row_content(self, df_record):
        data_rows = []
        row_heights = []

        # 辅助函数
        def add(row, h):
            data_rows.append(row)
            row_heights.append(h if h else 20)

        # 1. 标题行
        first_row = df_record.iloc[0]
        vis_path = first_row['VisPath']
        fname = Path(first_row['Path']).name
        
        # 处理主图
        if os.path.exists(vis_path):
            vis_img = RLImage(vis_path)
            aspect = vis_img.drawHeight / vis_img.drawWidth if vis_img.drawWidth > 0 else 1.0
            vis_img.drawWidth = 5 * inch
            vis_img.drawHeight = 5 * inch * aspect
            img_h = vis_img.drawHeight * 1.05
        else:
            vis_img = "Missing"
            img_h = 25

        add(["FileName", fname], 25)
        add([vis_img, ''], img_h)
        add(['Defect Count', str(len(df_record))], 25)

        # 2. 缺陷行
        for idx, row in df_record.iterrows():
            crop_path = row['CropPath']
            crop_img = RLImage(crop_path, width=2*inch, height=2*inch) if os.path.exists(crop_path) else "Missing"
            
            # --- 样式 0 的特定字段 ---
            add([f'Defect {idx+1}', crop_img], 2*inch + 10)
            add(['Category', row['Category']], 20)
            add(['Level', row['Level']], 20)
            add(['Action', row['Action']], 20)
            add(['Score', f"{row['Score']:.2f}"], 20)
        
        return data_rows, row_heights


class PDFExporterDetailed(BasePDFExporter):
    """
    样式 1: 详细报告 (增加 XYZ, Orientation, Floor, View)
    """
    def generate_row_content(self, df_record):
        data_rows = []
        row_heights = []

        def add(row, h):
            data_rows.append(row)
            row_heights.append(h if h else 20)

        # 1. 标题行 (同上，或者可以稍微变一下)
        first_row = df_record.iloc[0]
        vis_path = first_row['VisPath']
        fname = Path(first_row['Path']).name
        
        if os.path.exists(vis_path):
            vis_img = RLImage(vis_path)
            aspect = vis_img.drawHeight / vis_img.drawWidth if vis_img.drawWidth > 0 else 1.0
            vis_img.drawWidth = 5 * inch
            vis_img.drawHeight = 5 * inch * aspect
            img_h = vis_img.drawHeight * 1.05
        else:
            vis_img = "Missing"
            img_h = 25

        add(["FileName", fname], 25)
        add([vis_img, ''], img_h)
        # 可以在这里额外显示整张图的元数据
        add(['Location Info', f"Floor: {first_row.get('floor', 'N/A')} | View: {first_row.get('view', 'N/A')}"], 25)

        # 2. 缺陷行
        for idx, row in df_record.iterrows():
            crop_path = row['CropPath']
            crop_img = RLImage(crop_path, width=2*inch, height=2*inch) if os.path.exists(crop_path) else "Missing"
            
            add([f'Defect {idx+1}', crop_img], 2*inch + 10)
            
            # --- 样式 1 的特定字段 (新增内容) ---
            add(['Category', row['Category']], 20)
            
            # 获取元数据 (即使是 N/A)
            xyz = row.get('xyz', 'N/A')
            ori = row.get('orientation', 'N/A')
            
            # 用颜色标记重要信息 (可选)
            add(['XYZ Coords', str(xyz)], 20)
            add(['Orientation', str(ori)], 20)
            
            add(['Level', row['Level']], 20)
            add(['Action', row['Action']], 20)
            add(['Score', f"{row['Score']:.2f}"], 20)
        
        return data_rows, row_heights


class PDFExporterMeasurement(BasePDFExporter):
    """
    样式 3: 包含 像素/CM 测量信息 + 无人机摘要
    """

    def _add_summary_pages(self, elements, report_data):
        """
        重写摘要页：在原有基础上增加 Drone Info Table
        """
        # 1. 调用父类方法生成基础摘要 (如果父类方法拆分得当)
        # 但由于父类 logic 是写死的，我们这里可以直接重写整个摘要生成逻辑，
        # 或者在 BasePDFExporter 中把 summary 拆得更细。
        # 为了简单，这里**复制并修改**摘要生成逻辑。
        
        input_info = report_data['input']
        output_info = report_data['output']
        drone_info = report_data.get('drone_info', {})

        elements.append(Paragraph("<b>AI-Detection Result Report</b>", self.styles["font_title"]))
        elements.append(Spacer(1, 20))

        # --- Drone Info Table (新增) ---
        if drone_info:
            elements.append(Paragraph("Drone Information:", self.styles["font_section"]))
            data_drone = [
                ["Drone Model:", drone_info.get('Model', 'N/A')],
                ["Serial Number:", drone_info.get('Serial', 'N/A')],
                ["Camera Source:", drone_info.get('Camera', 'N/A')],
                ["Firmware Ver:", drone_info.get('Firmware', 'N/A')],
            ]
            t_drone = Table(data_drone, hAlign='LEFT', rowHeights=25, colWidths=[2*inch, 3*inch])
            t_drone.setStyle(self.style_blank)
            elements.append(t_drone)
            elements.append(Spacer(1, 10))

        # --- Input Info ---
        elements.append(Paragraph("Input Information:", self.styles["font_section"]))
        shape_str = f"{input_info['shape'][0]}~{input_info['shape'][1]}, {input_info['shape'][2]}~{input_info['shape'][3]}"
        data_input = [
            ["Type of Data:", input_info['type'].title()],
            ["Number of Images:", input_info['number']],
            ["Shape Range:", shape_str]
        ]
        t_input = Table(data_input, hAlign='LEFT', rowHeights=25)
        t_input.setStyle(self.style_blank)
        elements.append(t_input)
        elements.append(Spacer(1, 10))

        # --- Detection Summary ---
        elements.append(Paragraph("Detection Summary:", self.styles["font_section"]))
        data_output = [
            ["Model Used:", output_info['model']],
            ["With Defects:", output_info['defects']],
            ["No Defects:", output_info['no defects']],
        ]
        t_output = Table(data_output, hAlign='LEFT', rowHeights=25)
        t_output.setStyle(self.style_blank)
        elements.append(t_output)
        elements.append(Spacer(1, 10))
        
        # --- Stats ---
        from reportlab.platypus import PageBreak
        # ... (统计表代码省略，同之前) ...
        elements.append(PageBreak())

    def generate_row_content(self, df_record):
        data_rows = []
        row_heights = []

        def add(row, h):
            data_rows.append(row)
            row_heights.append(h if h else 20)

        # 1. 标题行
        first_row = df_record.iloc[0]
        vis_path = first_row['VisPath']
        fname = Path(first_row['Path']).name
        
        # 处理图片... (代码同前，省略)
        if os.path.exists(vis_path):
            vis_img = RLImage(vis_path)
            aspect = vis_img.drawHeight / vis_img.drawWidth if vis_img.drawWidth > 0 else 1.0
            vis_img.drawWidth = 5 * inch
            vis_img.drawHeight = 5 * inch * aspect
            img_h = vis_img.drawHeight * 1.05
        else:
            vis_img = "Missing"
            img_h = 25

        add(["FileName", fname], 25)
        add([vis_img, ''], img_h)
        # 显示元数据
        meta_text = f"Floor: {first_row.get('floor','N/A')} | View: {first_row.get('view','N/A')}"
        add(['Location', meta_text], 25)

        # 2. 缺陷详情
        for idx, row in df_record.iterrows():
            crop_path = row['CropPath']
            crop_img = RLImage(crop_path, width=2*inch, height=2*inch) if os.path.exists(crop_path) else "Missing"
            
            # 左侧：图片 + 序号
            add([f'Defect {idx+1}', crop_img], 2*inch + 10)
            
            # 右侧：属性
            add(['Category', row['Category']], 20)
            add(['Level', row['Level']], 20)
            
            # --- 核心：尺寸信息 ---
            # 格式：Length: 100px (10.5cm)
            w_str = f"{row['W_pix']}px ({row['W_cm']}cm)"
            h_str = f"{row['H_pix']}px ({row['H_cm']}cm)"
            area_str = f"{row['Area_pix']}px² ({row['Area_cm2']}cm²)"
            
            add(['Width', w_str], 20)
            add(['Height', h_str], 20)
            add(['Area', area_str], 20)
            
            add(['Action', row['Action']], 20)

        return data_rows, row_heights